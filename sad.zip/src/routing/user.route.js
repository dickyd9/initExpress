const express = require("express")
const UserController = require("../modules/user/controller")
// import { checkJwt } from "../../common/middleware/auth"

const router = express.Router()

// router.get("/user", checkJwt, UserController.getUser)
router.get("/user", UserController.userProfile)
router.get("/user-list", UserController.getUser)
router.post("/signUp", UserController.newUser)

module.exports = router
