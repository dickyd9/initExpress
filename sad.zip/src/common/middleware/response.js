class Inteceptor {
  async response(model, req, message) {
    console.log(req.url)
    const page = parseInt(req.query.page, 10) || 1
    const pageSize = parseInt(req.query.pageSize, 10) || 10
    const offset = (page - 1) * pageSize

    if (req.url === "/user-list") {
      const datas = await model.findAll({
        attributes: [
          "fullname",
          "address",
          "email",
          "is_email_verified",
          "createdAt",
        ],
        // limit: pageSize,
        // offset: offset,
      })
      const total = await model.count()
      const totalPages = Math.ceil(total / pageSize)

      return new Promise((resolve, reject) => {
        const data = {
          message: message,
          data: datas,
          meta: {
            totalData: total,
            limit: pageSize,
            page: offset,
            totalPages,
          },
        }
        resolve(data)
      })
    } else {
      const datas = await model.findAll({
        limit: pageSize,
        offset: offset,
      })
      const total = await model.count()
      const totalPages = Math.ceil(total / pageSize)

      return new Promise((resolve, reject) => {
        const data = {
          message: message,
          data: datas,
          meta: {
            totalData: total,
            limit: pageSize,
            page: offset,
            totalPages,
          },
        }
        resolve(data)
      })
    }
  }

  errorHandler(err, res) {
    if (err.status) {
      res.status(err.status).json({ message: err.message })
    } else {
      res.status(500).json({ message: "Terjadi kesalahan dalam server" })
    }
  }
}

module.exports = new Inteceptor()
